package com.movies.appmovies

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
